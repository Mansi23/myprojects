package com.example.mansibhatt.practice1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mansibhatt.practice1.model.Movie;
import com.example.mansibhatt.practice1.model.MoviesResponse;
import com.example.mansibhatt.practice1.rest.ApiClient;
import com.example.mansibhatt.practice1.rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    // TODO - insert your themoviedb.org API KEY here
    private final static String API_KEY = "1a7da5ce0425910c27383306868e3d76";

    Button data;
    List<Movie> movies1 = new ArrayList<Movie>();
    List<Movie> movies = new ArrayList<Movie>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.movies_recycler_view);
        data = (Button) findViewById(R.id.button_data);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        if (API_KEY.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Please obtain your API KEY first from themoviedb.org", Toast.LENGTH_LONG).show();
            return;
        }

        ApiInterface apiService =
                ApiClient.getClient().create(ApiInterface.class);

        Call<MoviesResponse> call = apiService.getTopRatedMovies(API_KEY);
        call.enqueue(new Callback<MoviesResponse>() {
            @Override
            public void onResponse(Call<MoviesResponse> call, Response<MoviesResponse> response) {
                List<Movie> movies = response.body().getResults();
                movies1 = movies;
                Log.d(TAG, "Number of movies received: " + movies.size());
                recyclerView.setAdapter(new MoviesAdapter(movies, R.layout.list_item_movie, getApplicationContext()));
            }

            @Override
            public void onFailure(Call<MoviesResponse> call, Throwable t) {
                // Log error here since request failed
                Log.e(TAG, t.toString());
            }
        });

        data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                movies.clear();
                for (int i = 0; i < movies1.size(); i++) {
                    if (movies1.get(i).isSelected()) {
                        movies.add(movies1.get(i));
                    }
                }

             //   Toast.makeText(MainActivity.this, "item size:" + movies.size(), Toast.LENGTH_SHORT).show();

                Intent ii = new Intent(MainActivity.this, SelectedListActivity.class);
                ii.putExtra("data", (ArrayList<Movie>) movies);
                startActivity(ii);

            }
        });

    }

    public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MovieViewHolder> {

        private List<Movie> movies;
        private int rowLayout;
        private Context context;


        public class MovieViewHolder extends RecyclerView.ViewHolder {
            LinearLayout moviesLayout;
            TextView movieTitle;
            TextView data;
            TextView movieDescription;
            TextView rating;
            public CheckBox selectionState;
            LinearLayout layouttitle;

            public MovieViewHolder(View v) {
                super(v);
                moviesLayout = (LinearLayout) v.findViewById(R.id.movies_layout);
                movieTitle = (TextView) v.findViewById(R.id.title);
                data = (TextView) v.findViewById(R.id.subtitle);
                movieDescription = (TextView) v.findViewById(R.id.description);
                rating = (TextView) v.findViewById(R.id.rating);
                selectionState = (CheckBox) v.findViewById(R.id.chkselect);
                layouttitle = (LinearLayout) v.findViewById(R.id.layout_title);
            }
        }

        public MoviesAdapter(List<Movie> movies, int rowLayout, Context context) {
            this.movies = movies;
            this.rowLayout = rowLayout;
            this.context = context;
        }

        @Override
        public MoviesAdapter.MovieViewHolder onCreateViewHolder(ViewGroup parent,
                                                                int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
            return new MovieViewHolder(view);
        }


        @Override
        public void onBindViewHolder(final MovieViewHolder holder, final int position) {
            holder.movieTitle.setText(movies.get(position).getTitle());
            holder.data.setText(movies.get(position).getReleaseDate());
            holder.movieDescription.setText(movies.get(position).getOverview());
            holder.rating.setText(movies.get(position).getVoteAverage().toString());
            holder.selectionState.setChecked(movies.get(position).isSelected());
            holder.selectionState.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    movies.get(holder.getAdapterPosition()).setSelected(b);
                    //    Toast.makeText(context, "Selected items:"+movies.get(holder.getAdapterPosition()).getTitle(), Toast.LENGTH_SHORT).show();
                }
            });
//            holder.layouttitle.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    for(int i = 0;i<movies.size();i++) {
//                        if (movies.get(i).isSelected()) {
//                            Toast.makeText(context, "Selected items:" + movies.get(i).getTitle(), Toast.LENGTH_SHORT).show();
//                        }
//                    }
//                }
//            });

        }

        @Override
        public int getItemCount() {
            return movies.size();
        }
    }

}
