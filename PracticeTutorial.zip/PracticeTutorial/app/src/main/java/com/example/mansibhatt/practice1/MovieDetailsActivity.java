package com.example.mansibhatt.practice1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.mansibhatt.practice1.model.Movie;

public class MovieDetailsActivity extends AppCompatActivity {

    TextView txttitle,txtdesc,txtdate,txtlang,txtvote;
    ImageView mveimg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        Movie movie = (Movie) getIntent().getSerializableExtra("data");

        txttitle = (TextView)findViewById(R.id.textView_title);
        txtdesc = (TextView)findViewById(R.id.textView_desc);
        txtlang = (TextView)findViewById(R.id.textView_lang);
        txtdate = (TextView)findViewById(R.id.textView_date);
        txtvote = (TextView)findViewById(R.id.textView_vote);
        mveimg = (ImageView) findViewById(R.id.imageView_mveimg);

        txtlang.setText(movie.getOriginalLanguage());
        txtdesc.setText(movie.getOverview());
        txttitle.setText(movie.getTitle());
        txtdate.setText(movie.getReleaseDate());
        txtvote.setText( String.valueOf(movie.getVoteAverage()));

        Log.e("image",movie.getPosterPath());

        Glide.with(MovieDetailsActivity.this)
                .load("https://image.tmdb.org/t/p/w500"+movie.getPosterPath())
                .into(mveimg);

    }
}