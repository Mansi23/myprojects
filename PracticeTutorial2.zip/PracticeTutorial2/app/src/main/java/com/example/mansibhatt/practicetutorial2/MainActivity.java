package com.example.mansibhatt.practicetutorial2;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.example.mansibhatt.practicetutorial2.fragments.CalculateDistance;
import com.example.mansibhatt.practicetutorial2.fragments.GetLocation;
import com.example.mansibhatt.practicetutorial2.fragments.ViewAllLocation;
import com.example.mansibhatt.practicetutorial2.model.LatLong;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements GetLocation.SendMessage{

    private Toolbar toolbar;
    private TabLayout tabLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabLayout = (TabLayout) findViewById(R.id.tabs);
        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout.setupWithViewPager(viewPager);

    }

    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new GetLocation(), "Location");
        adapter.addFragment(new CalculateDistance(), "Distance");
        adapter.addFragment(new ViewAllLocation(), "All Location");
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        viewPager.setAdapter(adapter);
    }

    @Override
    public void sendData(ArrayList<LatLong> message) {
        String tag = "android:switcher:" + R.id.viewpager + ":" + 1;
        String tag1 = "android:switcher:" + R.id.viewpager + ":" + 2;
        CalculateDistance f = (CalculateDistance) getSupportFragmentManager().findFragmentByTag(tag);
        ViewAllLocation f1 = (ViewAllLocation) getSupportFragmentManager().findFragmentByTag(tag1);
        f.displayReceivedData(message);
        f1.displayReceivedData(message);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }


        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }
}
