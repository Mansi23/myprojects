package com.example.mansibhatt.practicetutorial2.fragments;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mansibhatt.practicetutorial2.MainActivity;
import com.example.mansibhatt.practicetutorial2.R;
import com.example.mansibhatt.practicetutorial2.model.LatLong;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import static android.content.Context.LOCATION_SERVICE;

/**
 * Created by Mansi Bhatt on 06-01-2018.
 */

public class GetLocation extends Fragment implements LocationListener {

    TextView txtlocation, txtlatitude, txtlongitude;

    public static final int RequestPermissionCode = 1;

    protected LocationManager locationManager;
    protected LocationListener locationListener;
    protected Context context;
    String lat;
    String provider;
    protected String latitude, longitude;
    protected boolean gps_enabled, network_enabled;
    private boolean GpsStatus;
    // The minimum distance to change Updates in meters
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 5; // 10 meters

    // The minimum time between updates in milliseconds
    private static final long MIN_TIME_BW_UPDATES = 1000; // 1 minute

    Location location; // location

    ArrayList<LatLong> latlog = new ArrayList<LatLong>();

    SendMessage SM;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_getlocation, container, false);

        txtlocation = (TextView) rootview.findViewById(R.id.textView_location);
        txtlatitude = (TextView) rootview.findViewById(R.id.textView_latitude);
        txtlongitude = (TextView) rootview.findViewById(R.id.textViewLongitude);

        latlog.clear();

        EnableRuntimePermission();
        CheckGpsStatus();
        getLocation2();

        Timer timer = new Timer();
        TimerTask hourlyTask = new TimerTask() {
            @Override
            public void run() {
                Log.e("1","min");
                getLocation2();
            }
        };
        timer.schedule(hourlyTask, 0l, 1000*10); // update every 1 minute

        return rootview;
    }


    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        Log.e("Latitude", "status");
    }

    @Override
    public void onProviderEnabled(String s) {
        Log.e("Latitude", "enable");
    }

    @Override
    public void onProviderDisabled(String s) {
        Log.e("Latitude", "disable");
    }

    public void CheckGpsStatus() {
        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        GpsStatus = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    public Location getLocation2() {
        try {

            if (!GpsStatus) {
                // no network provider is enabled
                Toast.makeText(getActivity(), "Please on your GPS or Location", Toast.LENGTH_SHORT).show();
            } else {
                if (GpsStatus) {
                    if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        // return TODO;
                        Log.e("activity1", "RLOC: GPS Enabled");
                    }
                    locationManager.requestLocationUpdates(
                            LocationManager.GPS_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    Log.e("activity", "RLOC: GPS Enabled");
                    if (locationManager != null) {
                        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                        Log.e("activity", "RLOC: loc by GPS");
                        latitude = String.valueOf(location.getLatitude());
                        longitude = String.valueOf(location.getLongitude());
                        Log.e("latitude", latitude);
                        Log.e("longitude", longitude);

                        txtlatitude.setText(String.valueOf(location.getLatitude()));
                        txtlongitude.setText(String.valueOf(location.getLongitude()));
                        try {
                            Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
                            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                            if (addresses != null && addresses.size() > 0) {
                                String cityName = addresses.get(0).getAddressLine(0);
                                txtlocation.setText(cityName);
                                LatLong lat = new LatLong();
                                lat.setLatitude(location.getLatitude());
                                lat.setLongitude(location.getLongitude());
                                lat.setPlacename(cityName);
                                latlog.add(lat);

                                Log.e("listsend", String.valueOf(latlog.size()));

                                SM.sendData(latlog);
                            }
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return location;
    }

    public void EnableRuntimePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)) {

            Toast.makeText(getActivity(), "ACCESS_FINE_LOCATION permission allows us to Access GPS in app", Toast.LENGTH_LONG).show();

        } else {

            ActivityCompat.requestPermissions(getActivity(), new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION}, RequestPermissionCode);

        }
    }

    @Override
    public void onRequestPermissionsResult(int RC, String per[], int[] PResult) {

        switch (RC) {

            case RequestPermissionCode:

                if (PResult.length > 0 && PResult[0] == PackageManager.PERMISSION_GRANTED) {

                    Toast.makeText(getActivity(), "Permission Granted, Now your application can access GPS.", Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(getActivity(), "Permission Canceled, Now your application cannot access GPS.", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public interface SendMessage {
        void sendData(ArrayList<LatLong> message);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            SM = (SendMessage) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException("Error in retrieving data. Please try again");
        }
    }

}
