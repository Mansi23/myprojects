package com.example.mansibhatt.practicetutorial2.model;

/**
 * Created by Mansi Bhatt on 07-01-2018.
 */

public class LatLong {

    private double latitude;
    private double longitude;
    private String placename;

    public LatLong() {
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getPlacename() {
        return placename;
    }

    public void setPlacename(String placename) {
        this.placename = placename;
    }
}
