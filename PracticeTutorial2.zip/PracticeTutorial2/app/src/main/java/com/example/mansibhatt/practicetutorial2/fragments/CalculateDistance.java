package com.example.mansibhatt.practicetutorial2.fragments;

import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.mansibhatt.practicetutorial2.R;
import com.example.mansibhatt.practicetutorial2.model.LatLong;

import java.util.ArrayList;

/**
 * Created by Mansi Bhatt on 06-01-2018.
 */

public class CalculateDistance extends Fragment {

    ArrayList<LatLong> latlog = new ArrayList<LatLong>();
    TextView txtlocation,txtDistance;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View rootview = inflater.inflate(R.layout.fragment_calculatedistance, container, false);

        Log.e("datalist0", String.valueOf(latlog.size()));

        txtlocation = (TextView) rootview.findViewById(R.id.textView_location);
        txtDistance = (TextView) rootview.findViewById(R.id.textView_Distance);

        txtlocation.setText(latlog.get(latlog.size()-1).getPlacename());

        Location startPoint=new Location("locationA");
        startPoint.setLatitude(latlog.get(0).getLatitude());
        startPoint.setLongitude(latlog.get(0).getLongitude());

        Location endPoint=new Location("locationA");
        endPoint.setLatitude(latlog.get(latlog.size()-1).getLatitude());
        endPoint.setLongitude(latlog.get(latlog.size()-1).getLongitude());

        double distance=startPoint.distanceTo(endPoint);

        txtDistance.setText(String.valueOf(distance)+ " meters");

        return rootview;
    }

    public void displayReceivedData(ArrayList<LatLong> message) {
        latlog = message;
        Log.e("data", String.valueOf(message.size()));
    }
}
