package com.example.mansibhatt.practicetutorial2.fragments;

import android.content.Context;
import android.graphics.Movie;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mansibhatt.practicetutorial2.R;
import com.example.mansibhatt.practicetutorial2.model.LatLong;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mansi Bhatt on 06-01-2018.
 */

public class ViewAllLocation extends Fragment {

    ArrayList<LatLong> latlog = new ArrayList<LatLong>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview =  inflater.inflate(R.layout.fragment_viewalllocation, container, false);
        Log.e("datalist1", String.valueOf(latlog.size()));

        final RecyclerView recyclerView = (RecyclerView) rootview.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(new LocationAdapter(latlog, R.layout.fragment_getlocation, getActivity()));

        return rootview;
    }

    public void displayReceivedData(ArrayList<LatLong> message) {
        latlog = message;
    }

    public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.MovieViewHolder> {

        private List<LatLong> places;
        private int rowLayout;
        private Context context;


        public class MovieViewHolder extends RecyclerView.ViewHolder {
            TextView address;
            TextView latitude;
            TextView longitude;


            public MovieViewHolder(View v) {
                super(v);
                address = (TextView) v.findViewById(R.id.textView_location);
                latitude = (TextView) v.findViewById(R.id.textView_latitude);
                longitude = (TextView) v.findViewById(R.id.textViewLongitude);
            }
        }

        public LocationAdapter(List<LatLong> places, int rowLayout, Context context) {
            this.places = places;
            this.rowLayout = rowLayout;
            this.context = context;
        }

        @Override
        public LocationAdapter.MovieViewHolder onCreateViewHolder(ViewGroup parent,
                                                                int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
            return new MovieViewHolder(view);
        }


        @Override
        public void onBindViewHolder(final MovieViewHolder holder, final int position) {
            holder.address.setText(places.get(position).getPlacename());
            holder.latitude.setText(String.valueOf(places.get(position).getLatitude()));
            holder.longitude.setText(String.valueOf(places.get(position).getLongitude()));
        }

        @Override
        public int getItemCount() {
            return places.size();
        }
    }

}
